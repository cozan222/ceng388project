<?php 
$username = "cemozan";
$name = "cemozan";
$query3 = "SELECT * FROM users WHERE username = ".$username." AND name = ".$name;
echo $query3;

?>