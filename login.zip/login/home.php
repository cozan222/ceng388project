<?php 
include('dbcon.php');
include('session.php'); 

$result=mysqli_query($con, "select * from users where user_id='$session_id'")or die('Error In Session');
$row=mysqli_fetch_array($result);

 ?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <center><h3>Welcome: <?php echo $row['username']; ?> </h3></center>
    <nav>
        <a href="insertNote.php" /> Insert Note
        <a href="uploadPhoto.php"/>Upload Photo
        <a href="forgot_password.php"/>Change Password
        <a href="logout.php">Log out</a>
    </nav>



</body>
</html>

